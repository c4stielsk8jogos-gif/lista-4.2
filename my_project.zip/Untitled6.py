idade = int(input("Digite sua idade: "))

if idade >= 18:
    print("Acesso Liberado ao Jogo")  # ³¹
else:
    print("Acesso Negado")  # ³¹
