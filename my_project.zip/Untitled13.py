tem_chave = True
distancia_porta = 1

if tem_chave and distancia_porta < 2:
    print("Porta Aberta!")  # ³¹
