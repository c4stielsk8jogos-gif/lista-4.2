pontos = 1200
nivel = 1
vida = 100

if pontos > 1000:
    nivel = 2
    vida += 100

print("Nível:", nivel)  # ³¹
print("Vida:", vida)  # ³¹
