numero = float(input("Digite um número: "))

if numero > 0:
    print("Positivo")  # ³¹
elif numero < 0:
    print("Negativo")  # ³¹
else:
    print("Zero")  # ³¹
