peso_atual = 48
limite_maximo = 50

if peso_atual + 5 > limite_maximo:
    print("Inventário Cheio!")  # ³¹
else:
    print("Item adicionado!")  # ³¹
