numero = int(input("Digite um número: "))

if numero % 2 == 0:
    print("Par")  # ³¹
else:
    print("Ímpar")  #
