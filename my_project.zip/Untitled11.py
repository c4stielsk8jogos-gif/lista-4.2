senha_mestra = "python123"
senha = input("Digite a senha: ")

if senha == senha_mestra:
    print("Senha correta!")  # ³¹
else:
    print("Senha incorreta!")  # ³¹
