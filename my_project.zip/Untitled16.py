print("1 - Falar")
print("2 - Atacar")
print("3 - Fugir")

escolha = int(input("Escolha uma opção: "))

if escolha == 1:
    print("Você iniciou um diálogo!")  # ³¹
elif escolha == 2:
    print("Você atacou o inimigo!")  # ³¹
elif escolha == 3:
    print("Você fugiu da batalha!")  # ³¹
else:
    print("Opção inválida!")  # ³
