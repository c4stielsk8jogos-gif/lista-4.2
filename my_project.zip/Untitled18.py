posicao_x = 1100

if posicao_x < 0 or posicao_x > 1024:
    print("Personagem fora da tela!")  # ³¹
else:
    print("Personagem dentro da tela!")  # ³¹
