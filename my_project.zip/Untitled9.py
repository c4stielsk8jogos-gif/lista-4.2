nota = float(input("Digite a nota do aluno: "))

if nota >= 7:
    print("Aprovado")  # ³¹
elif nota >= 5:
    print("Recuperação")  # ³¹
else:
    print("Reprovado")  # ³¹
